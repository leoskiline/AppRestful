package com.example.apprestful;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    private EditText mltPiada;
    private Button btnCarregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mltPiada = findViewById(R.id.mltPiada);
        btnCarregar = findViewById(R.id.btnCarregar);
        btnCarregar.setOnClickListener(e-> {
            CarregarPiada();
        });
    }

    private void CarregarPiada() {
        ChuckNorrisAPI cn = new ChuckNorrisAPI();
        try {
            String piadajson = cn.execute("https://api.chucknorris.io/jokes/random").get();
            JSONObject jsonObject = new JSONObject(piadajson);
            mltPiada.setText(jsonObject.getString("value"));
        } catch (Exception e) {
            Log.i("ERROR",e.getMessage());
        }
    }
}