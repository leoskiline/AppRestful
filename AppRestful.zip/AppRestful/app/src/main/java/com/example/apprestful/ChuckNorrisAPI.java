package com.example.apprestful;

import android.os.AsyncTask;
import android.util.Log;

import org.apache.commons.io.IOUtils;

import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ChuckNorrisAPI extends AsyncTask <String,Integer,String> {
    @Override
    protected String doInBackground(String... strings) {
        String myjson = "";
        try {
            URL url = new URL(strings[0]);
            InputStream is = url.openStream();
            myjson = IOUtils.toString(is, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            Log.i("ERROR",e.getMessage());
        }
        return myjson;
    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        super.onProgressUpdate(values);
    }
}
